<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 10/4/2018
 * Time: 11:29 PM
 */


$this->addScripts('jquery.min.js', VENDOR.'jquery/');
$this->addScripts('popper.min.js', VENDOR.'bootstrap/js/');
$this->addScripts('bootstrap.min.js', VENDOR.'bootstrap/js/');

$this->addScripts('jquery.slimscroll.js', VENDOR.'theme/js/');
$this->addScripts('sticky-kit.min.js', VENDOR.'sticky-kit-master/dist/');
$this->addScripts('sidebarmenu.js', VENDOR.'theme/js/');
$this->addScripts('waves.js', VENDOR.'theme/js/');
$this->addScripts('custom.min.js', VENDOR.'theme/js/');


