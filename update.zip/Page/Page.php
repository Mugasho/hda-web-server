<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 10/3/2018
 * Time: 6:31 PM
 * @property string pageTitle
 */

namespace Hda\Page;

class Page extends Master
{

    /**
     * Page constructor.
     * @param $pageTitle
     */
    public function __construct($pageTitle)
    {
        $this->setPageTitle($pageTitle);
        $this->setMetaAuthor('Lincoln');
        $this->setMetaDescription('HDA project');
        $this->setMetaViewport('width=device-width, initial-scale=1, shrink-to-fit=no');
        $this->setMetaKeywords('Health,directory,application');
        require 'Styles.php';
        require 'scripts.php';

        $this->addMenu('Home', '', 'mdi mdi-view-dashboard', null);
        $this->addMenu('Drugs', null, 'mdi mdi-pill', array(
            'add drug' => 'drugs/add/',
            'drug list' => 'drugs/',
            'reports'=>'drugs/report/'));
        $this->addMenu('Facilities', null, 'mdi mdi-medical-bag', array(
            'Add new'=>'facility/add/',
            'Facilities'=>'facility/'
        ));
        $this->addMenu('Health Workers', 'hw/', 'mdi mdi-account-multiple', array(
            'Add new'=>'hw/add/',
            'Health Workers'=>'hw/'
        ));
        $this->addMenu('Users', 'users/', 'mdi mdi-account', null);
        $this->addMenu('Login', 'login.php', 'mdi mdi-lock', null);


        $this->setCopyright('Copyright © 2018 HDA All rights reserved.');
    }

}