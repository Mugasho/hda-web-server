<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 9/30/2018
 * Time: 10:16 PM
 */

$db=new Hda\database\db();
$db->createTables();