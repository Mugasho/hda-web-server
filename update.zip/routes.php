<?php /** @noinspection PhpIncludeInspection */
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 12/25/2018
 * Time: 12:59 PM
 */

header("Content-Type: text/html");
$router = new AltoRouter();
$router->setBasePath('/app');

// Main routes that non-customers see
$router->map('GET','/', 'public/index.php', 'home');
$router->map('GET','/drugs/', 'public/drugs/index.php', 'drugs');
$router->map('GET|POST','/drugs/add/', 'public/drugs/add.php', 'add-drug');
$router->map('GET|POST','/drugs/detail/[*:id]/', 'public/drugs/detail.php', 'drug-detail');
$router->map('GET','/facility/', 'public/facility/index.php', 'facility');
$router->map('GET|POST','/facility/add/', 'public/facility/add.php', 'add-facility');
$router->map('GET|POST','/facility/detail/[*:id]/', 'public/facility/detail.php', 'facility-detail');
$router->map('GET','/facility/api/', 'public/facility/api.php', 'facilityAPI');
$router->map('GET','/hw/', 'public/hw/index.php', 'hw');
$router->map('GET|POST','/hw/add/', 'public/hw/add.php', 'hw-add');
$router->map('GET','/users/', 'public/users/index.php', 'users');
$router->map('GET|POST','/register/', 'public/users/register.php', 'register');
$router->map('POST','/users/api/[*:action]/', 'public/users/api.php', 'userAPI');
$router->map('GET|POST','/login/', 'public/login.php', 'login');

// Special (payments, ajax processing, etc)
$router->map('GET','/charge/[*:customer_id]/','charge.php','charge');
$router->map('GET','/pay/[*:status]/','payment_results.php','payment-results');

// API Routes
$router->map('GET','/facility/api/[*:key]/[*:id]/', 'public/facility/api.php', 'api');
$router->map('GET','/drugs/api/[*:key]/[*:id]/', 'public/drugs/api.php', 'drugs-api');
$router->map('GET','/drugs/api/[*:key]/[*:limit]/', 'public/drugs/api.php', 'drugs-limit');

/* Match the current request */
$match = $router->match();
if($match) {
    require $match['target'];
}
else {
    header("HTTP/1.0 404 Not Found");
    require 'utils/404.php';
}