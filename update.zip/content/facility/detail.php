<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 2/4/2019
 * Time: 2:16 PM
 */

$facility = $this->getPageVars();
$allHW = $this->getPageVars2();


function getColor($reason)
{
    switch ($reason) {
        case 'Active':
            $color = 'success';
            break;
        case 'Inactive':
            $color = 'info';
            break;
        default:
            $color = 'danger';
            break;
    }
    return $color;
}

?>

<div class="row">

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <b><?php echo strtoupper($facility['facility']) ?></b>
                <div class="btn-group pull-right">
                    <a href="#" class="btn btn-themecolor"><i class="mdi mdi-pencil"></i> </a>
                    <a href="#" class="btn btn-themecolor "><i class="mdi mdi-delete"></i> </a>
                    <a href="<?php echo BASE_PATH . 'facility/' ?>" class="btn btn-themecolor "><i
                            class="mdi mdi-view-grid"></i> </a>
                </div>

            </div>
            <!--accordion-->
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading1">
                        <!----> <h4 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1"
                               aria-expanded="true" aria-controls="collapse1">
                                Basic information
                            </a>
                        </h4>
                    </div>
                    <div id="collapse1" class="panel-collapse collapse show" role="tabpanel" aria-labelledby="heading1">
                        <div class="panel-body">
                            <h5>Name of facility</h5><?php echo $facility['facility'] ?>
                            <hr>
                            <h5>Sector</h5><?php echo $facility['sector'] ?>
                            <hr>
                            <h5>Category</h5><?php echo $facility['category'] ?>
                            <hr>
                            <h5>License</h5><?php echo $facility['license'] ?>
                            <hr>
                            <h5>Address</h5><?php echo $facility['address'] ?>

                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="heading2">
                        <h4 class="panel-title">
                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion"
                               href="#collapse2" aria-expanded="false" aria-controls="collapse2">
                               Contact information
                            </a>
                        </h4>
                    </div>
                    <div id="collapse2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
                        <div class="panel-body">
                            <h5>Contact name</h5><?php echo $facility['contact'] ?>
                            <hr>
                            <h5>Phone</h5><?php echo $facility['phone'] ?>
                            <hr>
                            <h5>email</h5><?php echo $facility['email'] ?>
                            <hr>
                            <h5>Qualification</h5><?php echo $facility['qualification'] ?>
                            <hr>
                            <h5>Address</h5><?php echo $facility['location'] ?>
                        </div>
                    </div>
                </div>

            </div>

            <!--end accordion-->

        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">
                <a href="#" class="btn btn-themecolor pull-right" data-toggle="modal" data-target="#hw-modal" disabled><i
                        class="mdi mdi-plus"></i> Add new </a> Health workers
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="datatable" class="table .color-table .purple-table">
                        <thead>
                        <tr>
                            <th>Name</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($allHW as $hw) {
                            $status = !is_null($hw['status']) ? $hw['status'] : 'Active';
                            echo '<tr>
                        <td>
                            ' . $hw['names'] . '
                        </td>
                        <td>
                            ' .$hw['position'] . '
                        </td>
                         <td>
                         <span class="label label-rounded label-' . getColor($status) . ' mb-3 mr-3">
                            ' . $status . '
                         </span>
                        </td>
                        <td ><a href="'.BASE_PATH.'hw/detail/' . $hw['id'] . '/" ><i class="mdi mdi-pencil"></i> </a></td>
                    </tr>';
                        } ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <!-- hw modal -->
    <div id="hw-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
         aria-hidden="true" >
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Add Health Worker</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="hw-search" class="control-label">Health worker Number:</label>
                            <input type="text" class="form-control" id="hw-search" name="hw-hw-search" placeholder="Enter HW number" required="required" onkeyup="search(this.value)">
                        </div>
                        <div id="hw-table"></div>
                        <div class="form-group">
                            <label for="hw-search" class="control-label">Position:</label>
                            <input type="text" class="form-control" id="position" name="position" placeholder="Enter HW Position" required="required" onkeyup="search(this.value)">
                        </div>
                        <input id="hw-id" name="hw-id"  hidden="hidden" required="required">
                        <input id="fc-id" name="fc-id" hidden="hidden">
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.modal -->


</div>
<script>
    function search(str) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                var myArr = JSON.parse(this.responseText);
                var tbl='<table class="table table-striped">\n' +
                    '\n' +
                    '                                        <tbody>\n' +
                    '                                            <tr>\n' +
                    '                                                <td>'+myArr["id"]+'</td>\n' +
                    '                                                <td>'+myArr["name"]+'</td>\n' +
                    '                                                <td class="text-nowrap">\n' +
                    '                                                    <a href="<?php echo BASE_PATH?>hw/detail/'+myArr["id"]+'/" class="btn btn-primary btn-sm"> <i class="fa fa-search text-white"></i> </a>\n' +
                    '                                                    <button type="submit" class="btn btn-danger btn-sm waves-effect waves-light"><i class="fa fa-plus text-white"></i></button>\n' +
                    '                                                </td>\n' +
                    '                                            </tr>\n' +
                    '                                            \n' +
                    '                                              \n' +
                    '                                        </tbody>\n' +
                    '                                    </table>';
                document.getElementById("hw-id").value=myArr['id'];
                document.getElementById("fc-id").value=<?php echo $facility['id'] ?>;
                document.getElementById("hw-table").innerHTML = myArr['error'] === false ? tbl : "Not found";

            }
        };
        xmlhttp.open("GET", "<?php echo BASE_PATH?>facility/api/hw/"+str+"/", true);
        xmlhttp.send();
    }
</script>

