<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 10/6/2018
 * Time: 7:35 PM
 */

$hospital=new Hda\Page\Page('Facilities');

$db=new Hda\database\db();
$db->start_session();
if($db->login_check()==true):
    $hospital->setPageContent('facility/facility');
    $hospital->makePage();
else:
    $hospital->setPageError('Login first',null,'danger');
    header('Location:'. BASE_PATH.'login/');
endif;