<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 12/27/2018
 * Time: 3:04 PM
 */

$hospital=new Hda\Page\Page('HospitalsAPI');
$db=new Hda\database\db();
$response = array("error" => FALSE);

if ($match['params']['key']=='hw') {
    $hwID = $match['params']['id'];
    $hws = $db->getHwByID($hwID);
    if ($hws != null) {
        // doctor is found
        $response["error"] = FALSE;
        $response["id"] = $hws["id"];
        $response["name"]=$hws["names"];
        echo json_encode($response);
    } else {
        // user is not found with the credentials
        $response["error"] = TRUE;
        $response["error_msg"] = "not found!";
        echo json_encode($response);
    }
}