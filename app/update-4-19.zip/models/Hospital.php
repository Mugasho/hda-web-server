<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 12/27/2018
 * Time: 3:49 PM
 */

namespace Hda\models;


class Hospital
{

}