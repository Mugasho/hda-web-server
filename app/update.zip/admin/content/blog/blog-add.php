<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 3/7/2019
 * Time: 2:55 PM
 */

?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header text-primary">
                Basic Information <a href="<?php echo ADMIN_PATH . 'blog/' ?>"
                                     class="btn btn-info pull-right"><i class="mdi mdi-view-list"></i> Drug list </a>
            </div>
            <form  method="post">
                <div class="card-body">
                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="product-title">Name of Drug</label>
                                    <input type="text" class="form-control" id="name_of_drug"  name="name_of_drug" placeholder="Brand name"
                                           required="required">
                                </div>
                                <div class="form-group">
                                    <label for="product-subtitle">Generic Name</label>
                                    <input type="text" class="form-control" id="generic_name_of_drug" name="generic_name_of_drug"
                                           placeholder="Generic name" value="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="product-type">Dosage form</label>
                                    <input type="text" class="form-control" id="dosage_form" name="dosage_form" placeholder="Dispensed as">
                                </div>
                                <div class="form-group">
                                    <label for="product-year">Pack size</label>
                                    <input type="text" class="form-control" id="pack_size" name="pack_size" placeholder="Size of pack">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <label for="product-desc">content</label>
                                    <textarea id="content"  name="content" rows="5" class="form-control"
                                              placeholder="Post content"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-lg-12">
                            <label for="profile-pic">Profile Picture</label>
                            <input type="file" class="dropify" id="profile-pic" name="profile-pic"
                                   placeholder="Profile pic" required="required">
                        </div>
                    </div>
                </div>
                <div class="card-footer text-lg-center">
                    <button type="submit" class="btn btn-primary ">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
