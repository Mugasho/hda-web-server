<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 10/4/2018
 * Time: 11:31 PM
 */

$this->addStyle('bootstrap.css', VENDOR.'bootstrap/css/');
$this->addStyle('style.css', VENDOR.'theme/css/');
$this->addStyle('blue.css', VENDOR.'theme/css/colors/');
$this->addStyle('fontawesome-all.min.css', VENDOR.'font-awesome-5/css/');
$this->addStyle('toastr.min.css', VENDOR.'toastr/');
