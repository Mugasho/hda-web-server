<?php
/**
 * Created by PhpStorm.
 * User: LINCOLN
 * Date: 3/7/2019
 * Time: 12:02 PM
 */


$drugs = new Hda\Page\FrontPage('Blog');
$db = new Hda\database\db();
$drugs->setPageContent('blog/blog');
$drugs->makePage();